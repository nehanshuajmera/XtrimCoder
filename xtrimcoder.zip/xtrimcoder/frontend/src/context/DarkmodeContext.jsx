import axios from "axios";
import React, { createContext, useEffect, useState } from "react";

const DarkmodeContext = createContext();



function DarkmodeContextProvider(props) {

    const [isChecked, setIsChecked] = useState(true);
    async function  handleOnChange(){
      setIsChecked(!isChecked);
      localStorage.setItem("DarkMode",isChecked);
    };
    
  return (
    <DarkmodeContext.Provider value={{isChecked, handleOnChange}}>
      {props.children}
    </DarkmodeContext.Provider>
  );
}

export default DarkmodeContext;
export { DarkmodeContextProvider };