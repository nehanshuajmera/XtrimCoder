import React from 'react'
import './timeline.css'

export default function Timeline() {
  return (
    <div>
      {/* <div >
<ul className="timeline">
<li>
  <div className="direction-r">
    <div className="flag-wrapper">
      <span className="flag">January</span>
      <span className="time-wrapper"><span className="time">2022- present</span></span>
    </div>
    <div className="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora</div>
  </div>
</li>

<li>
  <div className="direction-l">
    <div className="flag-wrapper">
      <span className="flag">Feburary</span>
      <span className="time-wrapper"><span className="time">2021 - 2024</span></span>
    </div>
    <div className="desc">Gameskraft, JPMC Code for Good (Hackathon)</div>
  </div>
</li>

<li>
  <div className="direction-r">
    <div className="flag-wrapper">
      <span className="flag">March</span>
      <span className="time-wrapper"><span className="time">2022- present</span></span>
    </div>
    <div className="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora</div>
  </div>
</li>

<li>
  <div className="direction-l">
    <div className="flag-wrapper">
      <span className="flag">April</span>
      <span className="time-wrapper"><span className="time">2021 - 2024</span></span>
    </div>
    <div className="desc">Gameskraft, JPMC Code for Good (Hackathon)</div>
  </div>
</li>

<li>
  <div className="direction-r">
    <div className="flag-wrapper">
      <span className="flag">May</span>
      <span className="time-wrapper"><span className="time">2022- present</span></span>
    </div>
    <div className="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora</div>
  </div>
</li>

<li>
  <div className="direction-l">
    <div className="flag-wrapper">
      <span className="flag">June</span>
      <span className="time-wrapper"><span className="time">2021 - 2024</span></span>
    </div>
    <div className="desc">Gameskraft, JPMC Code for Good (Hackathon)</div>
  </div>
</li>

<li>
  <div className="direction-r">
    <div className="flag-wrapper">
      <span className="flag">July</span>
      <span className="time-wrapper"><span className="time">2022- present</span></span>
    </div>
    <div className="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora</div>
  </div>
</li>

<li>
  <div className="direction-l">
    <div className="flag-wrapper">
      <span className="flag">August</span>
      <span className="time-wrapper"><span className="time">2021 - 2024</span></span>
    </div>
    <div className="desc">Gameskraft, JPMC Code for Good (Hackathon)</div>
  </div>
</li>

<li>
  <div className="direction-r">
    <div className="flag-wrapper">
      <span className="flag">September</span>
      <span className="time-wrapper"><span className="time">2022- present</span></span>
    </div>
    <div className="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora</div>
  </div>
</li>

<li>
  <div className="direction-l">
    <div className="flag-wrapper">
      <span className="flag">Octomber</span>
      <span className="time-wrapper"><span className="time">2021 - 2024</span></span>
    </div>
    <div className="desc">Gameskraft, JPMC Code for Good (Hackathon)</div>
  </div>
</li>

<li>
  <div className="direction-r">
    <div className="flag-wrapper">
      <span className="flag">November</span>
      <span className="time-wrapper"><span className="time">2022- present</span></span>
    </div>
    <div className="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora</div>
  </div>
</li>

<li>
  <div className="direction-l">
    <div className="flag-wrapper">
      <span className="flag">December</span>
      <span className="time-wrapper"><span className="time">2021 - 2024</span></span>
    </div>
    <div className="desc">Gameskraft, JPMC Code for Good (Hackathon)</div>
  </div>
</li>


</ul>
  </div>
 */}

<header>
    <br/>
    <h1>Which Company? Hire's When?</h1>
</header>

<ul class="timeline" style={{color:"black"}}>

  <li>
    <div class="direction-r">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">January</span>
        <span class="time-wrapper"><span class="time">2022- present</span></span>
      </div>
      <div class="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora.</div>
    </div>
  </li>

  <li>
    <div class="direction-l">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">Feburary</span>
        <span class="time-wrapper"><span class="time">2021 - 2024</span></span>
      </div>
      <div class="desc">Gameskraft, JPMC Code for Good (Hackathon).</div>
    </div>
  </li>

  <li>
    <div class="direction-r">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">March</span>
        <span class="time-wrapper"><span class="time">2022- present</span></span>
      </div>
      <div class="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora.</div>
    </div>
  </li>

  <li>
    <div class="direction-l">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">April</span>
        <span class="time-wrapper"><span class="time">2021 - 2024</span></span>
      </div>
      <div class="desc">Gameskraft, JPMC Code for Good (Hackathon).</div>
    </div>
  </li>

  <li>
    <div class="direction-r">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">May</span>
        <span class="time-wrapper"><span class="time">2022- present</span></span>
      </div>
      <div class="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora.</div>
    </div>
  </li>

  <li>
    <div class="direction-l">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">June</span>
        <span class="time-wrapper"><span class="time">2021 - 2024</span></span>
      </div>
      <div class="desc">Gameskraft, JPMC Code for Good (Hackathon).</div>
    </div>
  </li>

  <li>
    <div class="direction-r">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">July</span>
        <span class="time-wrapper"><span class="time">2022- present</span></span>
      </div>
      <div class="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora.</div>
    </div>
  </li>

  <li>
    <div class="direction-l">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">August</span>
        <span class="time-wrapper"><span class="time">2021 - 2024</span></span>
      </div>
      <div class="desc">Gameskraft, JPMC Code for Good (Hackathon).</div>
    </div>
  </li>

  <li>
    <div class="direction-r">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">September</span>
        <span class="time-wrapper"><span class="time">2022- present</span></span>
      </div>
      <div class="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora.</div>
    </div>
  </li>

  <li>
    <div class="direction-l">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">Octomber</span>
        <span class="time-wrapper"><span class="time">2021 - 2024</span></span>
      </div>
      <div class="desc">Gameskraft, JPMC Code for Good (Hackathon).</div>
    </div>
  </li>

  <li>
    <div class="direction-r">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">November</span>
        <span class="time-wrapper"><span class="time">2022- present</span></span>
      </div>
      <div class="desc">Expedia, Media.in, Yellow Messanger, GeeksforGeeks, Codenation, JP Morgan, Quora.</div>
    </div>
  </li>

  <li>
    <div class="direction-l">
      <div class="flag-wrapper">
        <span class="hexa"></span>
        <span class="flag">December</span>
        <span class="time-wrapper"><span class="time">2021 - 2024</span></span>
      </div>
      <div class="desc">Gameskraft, JPMC Code for Good (Hackathon).</div>
    </div>
  </li>

</ul>


    </div>
  )
}
