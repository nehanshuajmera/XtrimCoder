import React from 'react'

export default function Question(props) {
   return (
    <a target="_blank" href={props.link} class="list-group-item d-flex justify-content-between align-items-center">
    {props.title}
    <span class="badge badge-secondary badge-pill">
      <img  src='https://leetcode.com/_next/static/images/logo-dark-c96c407d175e36c81e236fcfdd682a0b.png' width={"20px"} alt='leetcode'/>
    </span>
    </a>
  )
}
